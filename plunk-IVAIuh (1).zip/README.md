# Angular 2.0.0 + TypeScript Plunker Starter Kit

I couldn't find this elsewhere, so I created one. 
This is a simple Angular 2.0.0 (final) + TypeScript plunker. Fork it.